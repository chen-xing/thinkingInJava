### sameSite的问题



https://blog.csdn.net/qq_37060233/article/details/86595102





https://www.cnblogs.com/kevinblandy/p/13589864.html





要求springframework.http 5.0以上版本