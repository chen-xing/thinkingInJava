# js实现图片和base64互转

## 1、图片转base64

