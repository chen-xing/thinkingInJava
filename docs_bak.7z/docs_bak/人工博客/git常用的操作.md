###  git常用的操作

#### 1、回归合并代码的请求

```
git checkout . && git clean -xdf
```



#### 2、强制删除本地的代码分支

```
git branch -D branchName
```



#### 3、检出代码到本地

```
git checkout -b 本地分支名 远程分支名
```

