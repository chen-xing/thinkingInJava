# 如何复制pdf属性中的内容

复制的内容包括文档属性、签名属性等.

![如何复制pdf中的属性](https://cdn.jsdelivr.net/gh/chen-xing/figure_bed_02/cdn/20210729210352912.png)



> **操作步骤**：鼠标左键双击即可

